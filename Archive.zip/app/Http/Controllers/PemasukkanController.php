<?php

namespace App\Http\Controllers;

use App\Models\Pemasukkan;
use Illuminate\Http\Request;

class PemasukkanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pemasukkan  $pemasukkan
     * @return \Illuminate\Http\Response
     */
    public function show(Pemasukkan $pemasukkan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pemasukkan  $pemasukkan
     * @return \Illuminate\Http\Response
     */
    public function edit(Pemasukkan $pemasukkan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pemasukkan  $pemasukkan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pemasukkan $pemasukkan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pemasukkan  $pemasukkan
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pemasukkan $pemasukkan)
    {
        //
    }
}
